const { cleanUpID } = require('./utils');

// TODO: get ID from stdin

const id = "7-623";

console.log(cleanUpID(id));
// output: 7623
