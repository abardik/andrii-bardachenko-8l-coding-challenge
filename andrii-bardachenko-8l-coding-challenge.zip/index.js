// Runs all tasks

require('./task1');
require('./task2');
require('./task3');
